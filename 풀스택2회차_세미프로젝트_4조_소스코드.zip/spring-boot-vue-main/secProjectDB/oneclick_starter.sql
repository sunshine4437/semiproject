show autocommit;
@".\member.sql";
@".\product.sql";
@".\order.sql";
@".\basket.sql";
@".\qna.sql";
@".\review.sql";
commit;